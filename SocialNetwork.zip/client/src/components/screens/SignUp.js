import React from 'react'

function SignUp() {
  return (
    <div>I am Signup </div>
  )
}

export default SignUp